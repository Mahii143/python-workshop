a = []

for i in list(map(int,input().split())):

    a.append(str(i))

print(" ".join(a[::-1]))
