a = list(map(int,input().split()))
a.sort()
print(*a)
