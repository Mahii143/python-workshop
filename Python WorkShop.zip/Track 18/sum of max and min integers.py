a = list(map(int,input().split()))
print(min(a)+max(a))
