a = list(map(int,input().split()))
print(sum(a))
