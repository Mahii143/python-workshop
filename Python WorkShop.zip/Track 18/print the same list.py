numList = [*map(int,input().split())]
print(*numList)
